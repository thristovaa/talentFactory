-- phpMyAdmin SQL Dump
-- version 4.9.10
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Sep 07, 2022 at 12:50 PM
-- Server version: 5.7.24
-- PHP Version: 7.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `talent_factory`
--

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `cat_id` int(11) NOT NULL,
  `cat_title` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`cat_id`, `cat_title`) VALUES
(1, 'Trending'),
(2, 'Art'),
(3, 'Digital art'),
(4, 'Photography'),
(5, 'Videos');

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `create_id` int(11) NOT NULL,
  `create_title` varchar(255) NOT NULL,
  `create_description` text NOT NULL,
  `create_author` varchar(255) NOT NULL,
  `create_category` varchar(255) NOT NULL,
  `create_rating` varchar(11) NOT NULL DEFAULT '0',
  `create_date` date NOT NULL,
  `create_image` text NOT NULL,
  `create_price` int(11) NOT NULL,
  `create_author_image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`create_id`, `create_title`, `create_description`, `create_author`, `create_category`, `create_rating`, `create_date`, `create_image`, `create_price`, `create_author_image`) VALUES
(8, ':)', '...', '_thristova_', 'Art', '0', '2022-09-06', 'unknown.png', 70, '197864918_1826320864214263_7992223653146136488_n.jpg'),
(9, ':)', '.........', '_thristova_', 'Digital art', '0', '2022-09-06', '37c1a622ca47ced525de02ab3271b6ca.jpg', 90, '197864918_1826320864214263_7992223653146136488_n.jpg'),
(10, ':)))', 'kotka', 'root', 'Digital art', '4.67', '2022-09-07', 'cat9.jpg', 40, '19de57581bae7e37237a09bf06ff5947.jpg'),
(11, 'kotka', 'kotkaaaaaaaaa', 'root', 'Digital art', '0', '2022-09-07', 'cat7.png', 10, '19de57581bae7e37237a09bf06ff5947.jpg'),
(12, 'kotkiii', 'raya', 'root', 'Digital art', '4.00', '2022-09-07', 'cat13.jpg', 30, '19de57581bae7e37237a09bf06ff5947.jpg'),
(13, 'kotka', 'art', '_thristova_', 'Digital art', '3.36', '2022-09-07', 'cat1.png', 20, '197864918_1826320864214263_7992223653146136488_n.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `posts_to_categories`
--

CREATE TABLE `posts_to_categories` (
  `id` int(11) NOT NULL,
  `post_id` int(11) NOT NULL,
  `cat_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `rating`
--

CREATE TABLE `rating` (
  `id` int(11) NOT NULL,
  `rating` varchar(255) NOT NULL,
  `post_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `rating`
--

INSERT INTO `rating` (`id`, `rating`, `post_id`) VALUES
(6, '1', 13),
(7, '3', 13),
(8, '2', 13),
(9, '3', 13),
(10, '3', 13),
(11, '3', 13),
(12, '3', 13),
(13, '3', 13),
(14, '3', 13),
(15, '5', 13),
(16, '4', 13),
(17, '4', 13),
(18, '5', 13),
(19, '5', 13),
(20, '5', 10),
(21, '5', 10),
(22, '4', 10),
(23, '4', 12),
(24, '4', 12),
(25, '4', 12);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `user_password` varchar(255) NOT NULL,
  `user_firstname` varchar(255) NOT NULL,
  `user_lastname` varchar(255) NOT NULL,
  `user_email` varchar(255) NOT NULL,
  `user_image` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `user_password`, `user_firstname`, `user_lastname`, `user_email`, `user_image`) VALUES
(14, '_thristova_', '123456789', 'Raya', 'Hristova', 'raya.thristova@gmail.com', '197864918_1826320864214263_7992223653146136488_n.jpg'),
(15, 'root', 'root', 'Root', 'Rootov', 'root@test.bg', '19de57581bae7e37237a09bf06ff5947.jpg'),
(16, 'cat', 'cat', 'Cat', 'CAt', 'cat@cat.bg', 'cat11.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`cat_id`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`create_id`);

--
-- Indexes for table `posts_to_categories`
--
ALTER TABLE `posts_to_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rating`
--
ALTER TABLE `rating`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `cat_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `create_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `posts_to_categories`
--
ALTER TABLE `posts_to_categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `rating`
--
ALTER TABLE `rating`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
